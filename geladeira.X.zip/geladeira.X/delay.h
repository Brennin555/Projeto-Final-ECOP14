
#ifndef TEMPO_H
#define	TEMPO_H

void tempo(unsigned char i);
void tempoS(unsigned char i);

#endif	/* XC_HEADER_TEMPLATE_H */

